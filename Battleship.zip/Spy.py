import os
import random
import sys
import tkinter as tk
import tkinter.simpledialog as tsd
from tkinter import *

from PIL import Image, ImageTk

current_dir = os.path.dirname(os.path.realpath(__file__))

SPY_MODE = False
n = len(sys.argv)
if n == 2 and sys.argv[1] == "spy" or n == 2 and sys.argv[1] == "Spy"  :
    SPY_MODE = True

# Μέγεθος παραθύρου
WINDOW_SIZE = 512
# Μέγεθος πίνακα
BOARD_SIZE = 10
# Μέγεθος πλοίων
SHIP_SIZES = [5, 4, 3, 2]
# Χρώμα της θάλασσας
SEA_COLOR = "#95c2db"
# Χρώμα της θάλλασας όταν είναι απενεργοποιημένη
SEA_COLOR_ENEMY = "#db95b0"
# Χ΄ρωμα του πλοίου που έχει τοποθετηθεί
SHIP_COLOR = "#56f583"
# Χρώμα του πλοίου που τοποθετείται αυτή τη στιγμή
SHIP_PLACEMENT_COLOR = "#f5c056"
# Χρώμα του πλοίου που δεν μπορεί να τοποθετηθεί
SHIP_ERROR_COLOR = "#f5565e"
# Χρώμα του κουτιού που έχει χτυπηθεί με επιτυχία
HIT_SUCCESS_COLOR = "#00de7e"
# Χρώμα του κουτιού που έχει χτυπηθεί χωρίς επιτυχία
HIT_FAIL_COLOR = "#de004e"
# Λευκό χρώμα
WHITE_COLOR = "#ffffff"



#Start Vasilis
shipLetters = ["S5", "S4", "S3", "S2"] 
letterIndex = 0 

#Κλάση που αναπαριστά ένα πλοίο
class Ship:
    VERTICAL = 1
    HORIZONTAL = 2
    
    #Κατασκευάστρια μέθοδος που αρχικοποιεί το μέγεθος του πλοίου 
    def __init__(self, size):        
        self.size = size            
    
    #Μέθοδος που θέτει την αρχική θέση του πλοίου. Σε συνδυασμό με το size και το orientation
    #που καθορίζονται με άλλες μεθόδους, γίνεται ο καθορισμός του σε ποιες συνολικές θέσεις 
    #βρίσκεται το πλοίο
    def setPosition(self, x, y):
        self.x = x
        self.y = y 
    
    #Μέθοδος που θέτει τον προσανατολισμό του πλοίου
    def setOrientation(self, orientation):
        self.orientation = orientation
    
 
#Κλάση που αναπαριστά το ταμπλό του υπολογιστή και τοποθετεί τα πλοία
class ComputerBoard():
    #Μέθοδος που αρχικοποιεί μια αρχικά κενή λίστα που θα βάλουμε το κάθε σημείο του ταμπλό
    def __init__(self):
        self.board_locations = []
    
    #Μέθοδος που φτιάχνει το ταμπλό του υπολογιστή  
    def createBoard(self, main):
        for x in range(10):
            for y in range(11):
                #Φτιάχνουμε σε κάθε επανάληψη νέο σημείο 
                bl = BoardLocation(main.enemy_canvas, x, y, SEA_COLOR_ENEMY)
                #Προσθήκη συνθήκης για το οταν το ποντίκι  από το κουμπί
                bl.button.bind("<Enter>", main.onMouseEnter)
                #Προσθήκη συνθήκης για το οταν το ποντίκι βγαίνει από το κουμπί
                bl.button.bind("<Leave>", main.onMouseLeave)
                #Προσθήκη συνθήκης για το οταν το ποντίκι κάνει κλικ στο κουμπί
                bl.button.bind("<Button-1>", main.onMouseClickEnemy)
                #Βάζουμε σε κάθε επανάληψη το νέο σημείο στην λίστα των board_locations
                self.board_locations.append(bl)   
           
    #Μέθοδος που δέχεται την θέση x,y στο γραφικό grid και επιστρέφει το αντικείμενο τύπου BoardLocation
    #που είναι αποθηκευμένο μέσα στην λίστα board_locations
    def getBoardLocation(self, x, y):
        return self.board_locations[self.getBoardLocationInList(x, y)]
    
    #Μέθοδος που μεταφράζει τη θέση x,y του grid σε θέση μέσα στη λίστα board_locations.
    ################### Μετράει τα τετράγωνα όλων των προηγούμενων στειλών + τα τετράγωνα της τρέχουσα στήλης.
    def getBoardLocationInList(self, x, y):
        return 11*(x)+y
    
    #Μέθοδος που δημιουργεί τα πλοία του υπολογιστή 
    def setComputerShips(self):
        #Φτιάχνουμε μια αρχικά κενή λίστα που θα βάλουμε μέσα τις κατειλημμένες θέσεις και με μια for
        #η οποία θα πηγαίνει μέχρι το 110 επειδή το ταμπλό είναι 10x11 και όλες τις θέσεις τις αρχικοποιούμε με 0
        ###############################################  Έχει ξεμείνει 
        self.capturedPositions = []
        for i in range(110):
            self.capturedPositions.append(0) 
        
        #Δημιουργούμε αντικείμενα τύπου Ship και με την createship τα φτιάχνουμε
        self.fiveBlocksShip = Ship(5)
        self.createShip(self.fiveBlocksShip)
       
        self.fourBlocksShip = Ship(4)
        self.createShip(self.fourBlocksShip)                
           
        self.threeBlocksShip = Ship(3)    
        self.createShip(self.threeBlocksShip)            
        
        self.twoBlocksShip = Ship(2)
        self.createShip(self.twoBlocksShip)
    
    #Μέθοδος που δεσμεύει τις θέσεις ενός πλοίου ώστε κατ'αρχάς να μην χρησιμοποιηθούνε
    #από άλλο πλοίο και επίσης να υποδικνύει εάν ένα χτύπημα του παίκτη βρίσκει πλοίο ή όχι
    def reservePositionsInList(self, x, y, orientation, size):
        #Εκχωρούμε στην initPosition την πρώτη θέση που βρίσκεται το πλοίο 
        initPosition = self.getBoardLocationInList(x, y)
        #Αν ο προσανατολισμός είναι κατακόρυφος τότε με μία for έως το μήκος του πλοίου 
        #δεσμέουμε ότι όλες οι θέσεις που θα πάρει το πλοίο το οποίο επιτυγχάνεται με το +i 
        #θα είναι κατειλημμένες
        if orientation == Ship.VERTICAL:
            for i in range(size):
                self.board_locations[initPosition + i].has_ship = True
        #Αν ο προσανατολισμός είναι οριζόντιος τότε παίρνουμε ξεχωρίστα κάθε size και δεσμεύουμε. 
        elif orientation == Ship.HORIZONTAL:
            if size == 5: 
                self.board_locations[initPosition].has_ship = True
                self.board_locations[initPosition + 11].has_ship = True
                self.board_locations[initPosition + 22].has_ship = True
                self.board_locations[initPosition + 33].has_ship = True
                self.board_locations[initPosition + 44].has_ship = True    
            elif size == 4:
                self.board_locations[initPosition].has_ship = True
                self.board_locations[initPosition + 11].has_ship = True
                self.board_locations[initPosition + 22].has_ship = True
                self.board_locations[initPosition + 33].has_ship = True
            elif size == 3:
                self.board_locations[initPosition].has_ship = True
                self.board_locations[initPosition + 11].has_ship = True
                self.board_locations[initPosition + 22].has_ship = True
            elif size == 2:
                self.board_locations[initPosition].has_ship = True
                self.board_locations[initPosition + 11].has_ship = True
    
    #Μέθοδος που επιστρέφει True αν η θέση είναι δεσμευμένη, αλλιώς επιστρέφει False        
    def isPositionReserved(self, position):        
        return self.board_locations[position].has_ship == True
    
    #Μέθοδος που εξασφαλίζει ότι τα πλοία δεν θα βγουν εκτός ορίων 
    #και ότι δεν θα τοποθετηθούν το ένα πάνω στο άλλο
    def outOfBoundsOrReserved(self, x, y, orientation, size):
        #Εκχωρούμε στην initPosition την πρώτη θέση που βρίσκεται το πλοίο
        initPosition = self.getBoardLocationInList(x, y)
        
        #Αν ένα πλοίο είναι τοποθετημένο οριζόντια και είναι μεγέθους 5, ελέγχει εάν κάποια από τις θέσεις initPosition + 11, initPosition + 22, initPosition + 33 ή initPosition + 44 
        #υπερβαίνει τον συνολικό αριθμό θέσεων στο ταμπλό (10 * 11). Εάν κάποια από αυτές τις θέσεις είναι εκτός ορίων, επιστρέφει True. 
        #Επιπλέον, ελέγχει εάν κάποια από αυτές τις θέσεις είναι ήδη δεσμευμένη (isPositionReserved) και επιστρέφει True εάν κάποια από αυτές είναι.
        #Παρόμοιοι έλεγχοι γίνονται και για πλοία μεγεθών 4, 3 και 2, με τις αντίστοιχες θέσεις και κρατήσεις
        if orientation == Ship.HORIZONTAL:            
            if size == 5: 
                if (initPosition + 11 >= 10*11) or (initPosition + 22 >= 10 * 11) or (initPosition + 33 >= 10 * 11) or (initPosition + 44 >= 10 * 11):  
                    return True
                if self.isPositionReserved(initPosition) or self.isPositionReserved(initPosition+11) or self.isPositionReserved(initPosition+22) or self.isPositionReserved(initPosition+33) or self.isPositionReserved(initPosition+44):
                    return True
            elif size == 4: 
                if(initPosition + 11 >= 10*11) or (initPosition + 22 >= 10 * 11) or (initPosition + 33 >= 10 * 11):
                    return True
                if self.isPositionReserved(initPosition) or self.isPositionReserved(initPosition+11) or self.isPositionReserved(initPosition+22) or self.isPositionReserved(initPosition+33):
                    return True
            elif size == 3:
                if (initPosition + 11 >= 10*11) or (initPosition + 22 >= 10 * 11): 
                    return True
                if self.isPositionReserved(initPosition) or self.isPositionReserved(initPosition+11) or self.isPositionReserved(initPosition+22):
                    return True
            elif size == 2: 
                if (initPosition + 11 >= 10*11): 
                    return True
                if self.isPositionReserved(initPosition) or self.isPositionReserved(initPosition+11):
                    return True
        #Αν ένα πλοίο είναι τοποθετημένο κάθετα ελέγχει πρώτα εάν η θέση initPosition + μέγεθος υπερβαίνει τον συνολικό αριθμό θέσεων στο ταμπλό (11 * 10), υποδεικνύοντας ότι το πλοίο εκτείνεται πέρα από τα όρια του ταμπλό. 
        #Ελέγχει επίσης εάν το υπόλοιπο (initPosition + size) % 11 είναι μικρότερο από το μέγεθος του πλοίου, πράγμα που σημαίνει ότι το πλοίο τυλίγεται στην επόμενη σειρά. Εάν πληρούται κάποια από αυτές τις προϋποθέσεις, επιστρέφει True.
        elif orientation == Ship.VERTICAL: 
            if (initPosition + size >= 11*10) or ((initPosition + size) % 11 < size):                
                return True
            for i in range(initPosition, initPosition+size):
                if self.isPositionReserved(i):
                    return True
        
        #Επιστρέφουμε False αν το πλοίο δεν είναι εκτός ορίων ή όταν δεν επικαλύπτει κάποιο άλλο            
        return False  
    
    #Μέθοδος που δείχνει τα πλοία του υπολογιστή στο ταμπλό
    def showShipText(self, x, y, orientation, size, text):
        #Εάν ο προσανατολισμός του πλοίου είναι κατακόρυφος χρησιμοποιούμε τη μέθοδο getBoardLocation με τις συντεταγμένες x και y+i για πρόσβαση στην αντίστοιχη θέση του πλοίου για κάθε επανάληψη. 
        #Στη συνέχεια, ορίζει την ιδιότητα κειμένου του κουμπιού που σχετίζεται με τη θέση του πίνακα στην παρεχόμενη τιμή κειμένου χρησιμοποιώντας τη μέθοδο config(text=text). Αν τρέξουμε το πρόγραμμα
        #με όρισμα spy στη γραμμή εντολών τότε εμφανίζει τα πλοία του υπολογιστή
        for i in range(size):            
            if orientation == Ship.VERTICAL:
                self.getBoardLocation(x, y+i).button.config(text=text)
            else:
                self.getBoardLocation(x+i, y).button.config(text=text)
    
    #Mέθοδος που κατασκευάζει τα πλοία σε τυχαίες θέσεις
    def createShip(self, ship):
        global shipLetters
        global letterIndex
        while True:
            #Παίρνουμε τις τυχαίες θέσεις
            x = random.randint(0, 10)
            y = random.randint(0, 9)
            
            #Παίρνουμε τον τυχαίο προσανατολισμό, ορίζουμε την θέση και ορίζουμε και τον προσανατολισμό
            orientation = self.getRandomOrientation()
            ship.setPosition(x, y)
            ship.setOrientation(orientation)
            
            #Αν η outOfBoundsOrReserved επιστρέψει True τότε υπάρχει κάποιο πρόβλημα (το πλοίο είναι εκτός ορίων ή επικαλύπτει κάποιο άλλο πλοίο)
            if self.outOfBoundsOrReserved(x, y, orientation, ship.size) == True:
                continue
            else:
            #Αν η outOfBoundsOrReserved επιστρέψει False τότε εκχωρούμε στην μεταβλητή text το τρέχον πλοίο στην λίστα, δεσμεύονται οι θέσεις και το σταματάει. 
            #Όσον αφορά το SPY_MODE αν τρέξουμε το πρόγραμμα με python3 εκτελέσιμο_πρόγραμμα.py spy θα μπορούμε να δούμε τα πλοία που έχουν τοποθετηθεί στο ταμπλό του υπολογιστή
                text = shipLetters[letterIndex]
                letterIndex = letterIndex + 1
                if SPY_MODE == True:
                    self.showShipText(x, y, orientation, ship.size, text)
                self.reservePositionsInList(x,y,orientation, ship.size)
                break 
    
    #Μέθοδος που επιστρέφει έναν τυχαίο προσανατολισμό
    def getRandomOrientation(self):
        #Ship.Vertical = 1 , #Ship.Horizontal = 2 
        rnd_orientation = random.randint(Ship.VERTICAL,Ship.HORIZONTAL) 
        return rnd_orientation
        
#End Vasilis 








class Main:
    def __init__(self):
        self.root = Tk()
        # Δημιουργία frame
        self.frame = Frame(self.root)
        self.frame.pack(fill=BOTH, expand=1)
        
        # Label για την κατάσταση του παιχνιδιού
        self.game_state_label = Label(self.frame, text="Κατάσταση παιχνιδιού: Τοποθέτηση πλοίων")
        self.game_state_label.pack()
        
        # Label για τον πίνακα του αντιπάλου
        self.enemy_board_label = Label(self.frame, text="Ταμπλό αντιπάλου:")
        self.enemy_board_label.pack()
        
        # Δημιουργία canvas με το μέγεθος του παραθύρου για τον πίνακα του αντιπάλου
        self.enemy_canvas = Canvas(self.frame, width=WINDOW_SIZE, height=WINDOW_SIZE)
        self.enemy_canvas.pack(fill=BOTH , expand=1)
        
        # Label για τον πίνακα του παίκτη
        self.player_board_label = Label(self.frame, text="Ταμπλό παίκτη:")
        self.player_board_label.pack()
        
        # Δημιουργία canvas με το μέγεθος του παραθύρου για τον πίνακα του παίκτη
        self.canvas = Canvas(self.frame, width=WINDOW_SIZE, height=WINDOW_SIZE)
        self.canvas.pack(fill=BOTH , expand=1)
        
        # Δημιουργία μεταβλητών για την τοποθέτηση των πλοίων
        self.placing_horizontal = False
        self.selected_ship = 0
        self.hovered_location = None
        self.ship_placement_locations = []
        
        # Με το δεξί κλικ του ποντικιού αλλάζει η κατεύθυνση τοποθέτησης των πλοίων
        self.root.bind("<Button-3>", self.toggleOrientation)
        
        # Δημιουργία labels σχετικα με το παιχνίδι
        # Πλοία που τοποθετήθηκαν
        self.ship_placement_label = Label(self.frame, text="Πλοία που τοποθετήθηκαν: " + str(self.selected_ship) + "/" + str(len(SHIP_SIZES)))
        self.ship_placement_label.pack()
        # Κατεύθυνση τοποθέτησης
        self.orientation_label = Label(self.frame, text="Κατεύθυνση τοποθέτησης: Κάθετα")
        self.orientation_label.pack()

        self.player_hits = 0
        self.enemy_hits = 0
        
        self.initializeGame()

                    
    # Αλλαγή της κατεύθυνσης τοποθέτησης των πλοίων
    def toggleOrientation(self, event):
        # Αν δεν είναι στην κατάσταση τοποθέτησης πλοίων επιστρέφει και δεν κάνει τίποτα
        if self.game_state != "placing_ships":
            return
        
        self.placing_horizontal = not self.placing_horizontal
        self.orientation_label.config(text="Κατεύθυνση τοποθέτησης: Οριζόντια" if self.placing_horizontal else "Κατεύθυνση τοποθέτησης: Κάθετα")
        self.redrawBoard()
    
    # Αρχικοποίηση παιχνιδιού
    def initializeGame(self):
        # Δημιουργία πίνακα πλοίων
        self.board = []
        for x in range(BOARD_SIZE):
            # Προσθήκη κενής λίστας στον πίνακα
            self.board += [[]]
            for y in range(BOARD_SIZE):
                # Προσθήκη κενού κουμπιού στην λίστα
                board_location = BoardLocation(self.canvas, x, y)
                # Προσθήκη συνθήκης για το οταν το ποντίκι είναι πάνω από το κουμπί
                board_location.button.bind("<Enter>", self.onMouseEnter)
                # Προσθήκη συνθήκης για το οταν το ποντίκι βγαίνει από το κουμπί
                board_location.button.bind("<Leave>", self.onMouseLeave)
                self.board[x] += [board_location]
        
        
        # Start Vasilis  
        self.computerBoard = ComputerBoard()
        self.computerBoard.createBoard(self)
        self.computerBoard.setComputerShips()
        # End Vasilis 

        # Αρχικοποίηση της κατάστασης του παιχνιδιού
        self.game_state = "placing_ships"

        # Start Giwrgos 
        self.place_player_ships()
        # End Giwrgos 
        
    def onMouseLeave(self, event):
        # Εκκαθάριση του τρέχοντος κουμπιού που είναι πάνω από το ποντίκι
        self.hovered_location = None
    
    def onMouseEnter(self, event):        
        # Αποθήκευση του τρέχοντος κουμπιού που είναι πάνω από το ποντίκι
        self.hovered_location = event.widget
        self.redrawBoard()
        
    def onMouseClickEnemy(self, event):
        if self.game_state != "playing":
            return
        
        # hli = Hovered Location Info
        hli = self.getHoveredLocationGridInfo()
        x = hli[0]
        y = hli[1]
        # Παίρνουμε την τοποθεσία που βρίσκεται το ποντίκι πάνω από το κουμπί στον πίνακα του εχθρού
                    #location = self.enemy_board[x][y]
        
        # Start Vasilis 
        location = self.computerBoard.getBoardLocation(x, y)
        # End Vasilis 

            
        # Αν η τοποθεσία έχει ήδη χτυπηθεί τότε επιστρέφουμε από την συνάρτηση
        if location.has_been_hit:
            return
        
        # Αν η τοποθεσία δεν έχει ήδη χτυπηθεί τότε κάνουμε χτύπημα στην τοποθεσία
        self.hitLocation(location)
        if location.has_ship:
            self.player_hits += 1
            # if self.player_hits == sum(SHIP_SIZES):
                # self.root.messagebox.showinfo("Game over", "You Won!")

        self.computer_turn()

    # Start Giwrgos
    def computer_turn(self):
        while True:
            row, col = random.randint(0, 9), random.randint(1, 10)
            location = self.board[row][col]
            if location.has_been_hit == False:
                self.hitLocation(location)
                if location.has_ship:
                    self.enemy_hits += 1
                    #if self.enemy_hits == sum(SHIP_SIZES):
                    #    self.root.messagebox.showinfo("Game Over", "You lost!")
                break
    # End Giwrgos


    # Χτύπημα σε τοποθεσία
    def hitLocation(self, location):
        location.has_been_hit = True
        location.button.config(text="X", bg=HIT_SUCCESS_COLOR if location.has_ship else HIT_FAIL_COLOR, fg=WHITE_COLOR)
    
    # Start Giwrgos
    def place_player_ships(self):
     exited = False
     for ship in SHIP_SIZES:
        while True:
            if exited:
                break
            orientation = tsd.askstring("Τοποθέτηση πλοίων", "Εισάγετε 'h' για οριζοντια ή 'v' για κάθετα:")
            if orientation == None:
                exited = True
                break
            row = tsd.askinteger("Τοποθέτηση πλοίων", "Εισάγετε σειρά (0-9):")
            if row == None:
                exited = True
                break
            col = tsd.askinteger("Τοποθέτηση πλοίων", "Εισάγετε στήλη (0-9):")
            if col == None:
                exited = True
                break
            
            if orientation not in ["h", "v"] or not(0 <= row <= 9) or not(0 <= col <= 9):
                tk.messagebox.showinfo("Μη έγκυρη εισαγωγή", "Μη έγκυρη εισαγωγή. Try again.")
                continue

            if orientation == "h" and col + ship > 10:
                tk.messagebox.showinfo("Μη έγκυρη εισαγωγή", "Μη έγκυρη εισαγωγή. Προσπαθήστε ξανά.")
                continue
            
            if orientation == "v" and row + ship > 10:
                tk.messagebox.showinfo("Μη έγκυρη εισαγωγή", "Μη έγκυρη εισαγωγή. Προσπαθήστε ξανά.")
                continue
            
            if self.isPlacementValid(row, col, ship, orientation):
                for i in range(ship):
                    if orientation == "v":
                        self.board[row][col + i].has_ship = True
                    else:
                        self.board[row + i][col].has_ship = True
                
                self.redrawBoard()
                break
            else:
                tk.messagebox.showinfo("Μη έγκυρη εισαγωγή", "Μη έγκυρη εισαγωγή. Προσπαθήστε ξανά.")

        if exited:
            self.root.destroy()
            
        self.game_state = "playing"
        self.game_state_label.config(text="Κατάσταση παιχνιδιού: Παίζεις")
    # End Giwrgos

    # Ελέγχει αν η τοποθέτηση του πλοίου είναι έγκυρη
    def isPlacementValid(self, x, y, ship_size, horizontal):
        valid_placement = True
        # Έλεγχος για το αν η τοποθέτηση του πλοίου ειναι εκτός του πίνακα
        if horizontal:
            if x + ship_size > BOARD_SIZE:
                valid_placement = False
        else:
            if y + ship_size > BOARD_SIZE:
                valid_placement = False
        
        # Έλεγχος για το αν τοποθετούμε πάνω σε άλλο πλοίο
        for location in self.ship_placement_locations:
            if location.has_ship:
                valid_placement = False
        
        return valid_placement
    
    # Επιστρέφει την θέση του ποντικιού στον πίνακα (x, y)
    def getHoveredLocationGridInfo(self):
        if self.hovered_location == None:
            return -1, -1
        
        return self.hovered_location.grid_info().get("column"), self.hovered_location.grid_info().get("row")
    
    # Ζωγραφίζει το board
    def redrawBoard(self):
        # hli = Hovered Location Info
        hli = self.getHoveredLocationGridInfo()
        # Εκκαθάριση της λίστας με τις τοποθετήσεις του πλοίου
        self.ship_placement_locations = []
        # Για κάθε κουμπί στον πίνακα
        for x in range(BOARD_SIZE):
            for y in range(BOARD_SIZE):
                location = self.board[x][y]
                # Επαναφορά του χρώματος του κουμπιού
                if self.game_state == "placing_ships":
                    location.button.config(bg=SEA_COLOR)
                
                # Αν το κουμπί είναι στη λίστα με τις τοποθετήσεις του πλοίου
                if location in self.ship_placement_locations:
                    # Αν η τοποθέτηση του πλοίου είναι έγκυρη τότε θα είναι κίτρινο αλλιώς θα είναι κόκκινο
                    location.button.config(bg=self.isPlacementValid(hli[0], hli[1], SHIP_SIZES[self.selected_ship], self.placing_horizontal) and SHIP_PLACEMENT_COLOR or SHIP_ERROR_COLOR)
                else:
                    # Αν το κουμπί έχει πλοίο πάνω του τότε θα είναι πράσινο
                    if location.has_ship:
                        location.button.config(bg=SHIP_COLOR)

# Κλάση που αναπαριστά μια τοποθεσία στον πίνακα
class BoardLocation:
    def __init__(self, canvas, x, y, default_color=SEA_COLOR):
        self.button = Button(canvas)
        self.button.config(width=3, height=1, bg=default_color, border=1)
        self.button.grid(column=x, row=y)
        self.has_ship = False
        self.has_been_hit = False




main = Main()
main.root.mainloop()